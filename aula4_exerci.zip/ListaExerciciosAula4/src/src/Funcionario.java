package src;


public class Funcionario {
	private double Salario;
	private Cargo cargo;
	
	public Funcionario(Cargo loCargo) 
	{
		cargo = loCargo;
	}
	
	public  double getSalarioBase() {
		return Salario;
	}

	public Cargo getCargo() {
		// TODO Auto-generated method stub
		return cargo;
	}
	
	public double getSalarioLiquido() {
		 Double salario = cargo.CalculaRegrasSalario(this);
		 
		return salario;
	}
}

