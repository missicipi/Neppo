package src;


public class CalculadoraDeSalario {
	
	public double calcula(Funcionario funcionario) {
		if (funcionario==null)
			throw new RuntimeException("funcionario invalido");
		
		return funcionario.getSalarioLiquido();
	}
}
