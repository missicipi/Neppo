package src;


public class Cargo {
	
	private RegraDeCalculo regra;

	Cargo(RegraDeCalculo regra) {
		this.regra = regra;
	}

	public RegraDeCalculo getRegra() {
		return regra;
	}
	
	public double CalculaRegrasSalario(Funcionario funcionario) {
		return regra.calcula(funcionario);
		
	}
}
