package src;
public interface RegraDeCalculo {
	double calcula(Funcionario f);
}
