package Refatorar;

public class debitoContaCorrente {
	private validarSaldo validar;
	private emitirComprovante comprovante;
	
	
	public void  debitarConta(){
		
	}

}
