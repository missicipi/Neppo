package Refatorar;

public class emitirComprovante {

}
